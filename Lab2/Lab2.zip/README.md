-- INSTRUCTIONS --
1. Run python --version 2.7.10 is installed
2. Run `python lab2.py`
3. Enter 1, 2 for data related to the lab questions
Note: Lab Results will be in Lab2_data.xlsx and the report is Lab2_report.pdf