class Packet:
    def __init__(self, timestamp):
        self.timestamp = timestamp
